#problem 1
print("Hello, World!")

#problem2
import math
import os
import random
import re
import sys

if __name__ == '__main__':
    n = int(input().strip())
    check = {True: "Not Weird", False: "Weird"}
    print(check[n%2==0 and (n in range(2,6) or n > 20)])


#problem3
a = int(raw_input())
b = int(raw_input())

print a + b
print a - b
print a * b


#problem4
k = int(raw_input())

for i in range(k):
    print i * i

#problem5
def is_leap(year):
    leap = False
    
    # Write your logic here
    if year % 400 == 0:
        leap = True
    elif year % 100 == 0:
        leap = False
    elif year % 4 == 0:
        leap = True
    
    return leap
    
year = int(raw_input())
print is_leap(year)


#problem6
if __name__ == '__main__':
    n = int(input())
    for i in range(n):
        print(i+1,end="")

#problem7
if __name__ == '__main__':
    a = int(input())
    b = int(input())
    c=a//b
    d=a/b
    print("%d\n%f"%(c,d))
                    