# Set .add()


# Enter your code here. Read input from STDIN. Print output to STDOUT
m=int(input())
arr=set(input().strip() for _ in range(m))
print(len(arr))
