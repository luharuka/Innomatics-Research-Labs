# Polar Coordinates

# Enter your code here. Read input from STDIN. Print output to STDOUT
import cmath
r = complex(input().strip())
print(cmath.polar(r)[0])
print(cmath.polar(r)[1])