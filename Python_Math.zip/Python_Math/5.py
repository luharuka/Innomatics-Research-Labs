# Power - Mod Power
# Enter your code here. Read input from STDIN. Print output to STDOUT
from math import *
a=int(input())
b=int(input())
c=int(input())
d=pow(a,b)
print(int(d))
print(int(d%c))