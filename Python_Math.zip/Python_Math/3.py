# Triangle Quest 2

from math import pow



for i in range(1,int(input())+1):
    print(int(pow(pow(10,i)//9,2)))

